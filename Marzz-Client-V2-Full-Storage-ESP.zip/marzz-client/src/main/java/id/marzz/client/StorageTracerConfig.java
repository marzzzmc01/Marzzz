package id.marzz.client;

/**
 * Local preferences for the Storage Tracers module.
 *
 * The starter intentionally limits the feature to the block currently targeted
 * by the player's crosshair. It does not scan chunks or reveal occluded blocks.
 */
public final class StorageTracerConfig {
    private StorageTracerConfig() {}

    public static boolean enabled = true;
    public static boolean chest = true;
    public static boolean enderChest = true;
    public static boolean trappedChest = true;
    public static boolean shulker = true;
    public static boolean spawner = true;
    public static boolean barrel = true;
    public static boolean furnace = true;
}
