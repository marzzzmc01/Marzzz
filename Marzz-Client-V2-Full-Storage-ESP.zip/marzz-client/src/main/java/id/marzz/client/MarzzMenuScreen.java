package id.marzz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class MarzzMenuScreen extends Screen {
    private static final int PANEL = 0xF0141020;
    private static final int PANEL_INNER = 0xFF211A31;
    private static final int ACCENT = 0xFFB78CFF;
    private static final int MUTED = 0xFFB9ADC9;
    private static final int WHITE = 0xFFF7F2FF;

    private int panelLeft, panelTop, panelWidth, panelHeight;

    public MarzzMenuScreen() {
        super(Text.literal("Marzz Client"));
    }

    @Override
    protected void init() {
        clearChildren();
        panelWidth = Math.min(390, width - 24);
        panelHeight = Math.min(326, height - 20);
        panelLeft = (width - panelWidth) / 2;
        panelTop = (height - panelHeight) / 2;

        int gap = 8;
        int colWidth = (panelWidth - 36 - gap) / 2;
        int left = panelLeft + 10;
        int right = left + colWidth + gap;
        int y = panelTop + 61;

        section("HUD", y);
        y += 17;
        addToggle(left, y, colWidth, "Keystrokes", () -> MarzzHudConfig.showKeystrokes, v -> MarzzHudConfig.showKeystrokes = v);
        addToggle(right, y, colWidth, "FPS Counter", () -> MarzzHudConfig.showFps, v -> MarzzHudConfig.showFps = v);
        y += 24;
        addToggle(left, y, colWidth, "Coordinates HUD", () -> MarzzHudConfig.showCoordinates, v -> MarzzHudConfig.showCoordinates = v);

        y += 30;
        section("WORLD TOOLS", y);
        y += 17;
        addToggle(left, y, colWidth, "Chunk Borders", () -> WorldAnalyzerConfig.chunkBorders, v -> WorldAnalyzerConfig.chunkBorders = v);
        addToggle(right, y, colWidth, "Terrain Notes", () -> WorldAnalyzerConfig.exploredTerrainNotes, v -> WorldAnalyzerConfig.exploredTerrainNotes = v);
        y += 24;
        addToggle(left, y, colWidth, "World Coordinates", () -> WorldAnalyzerConfig.showCoordinates, v -> WorldAnalyzerConfig.showCoordinates = v);

        y += 30;
        section("STORAGE FILTERS", y);
        y += 17;
        addToggle(left, y, colWidth, "Storage Tracer", () -> StorageTracerConfig.enabled, v -> StorageTracerConfig.enabled = v);
        addToggle(right, y, colWidth, "Chest", () -> StorageTracerConfig.chest, v -> StorageTracerConfig.chest = v);
        y += 24;
        addToggle(left, y, colWidth, "Ender Chest", () -> StorageTracerConfig.enderChest, v -> StorageTracerConfig.enderChest = v);
        addToggle(right, y, colWidth, "Trapped Chest", () -> StorageTracerConfig.trappedChest, v -> StorageTracerConfig.trappedChest = v);
        y += 24;
        addToggle(left, y, colWidth, "Shulker Box", () -> StorageTracerConfig.shulker, v -> StorageTracerConfig.shulker = v);
        addToggle(right, y, colWidth, "Spawner", () -> StorageTracerConfig.spawner, v -> StorageTracerConfig.spawner = v);
        y += 24;
        addToggle(left, y, colWidth, "Barrel", () -> StorageTracerConfig.barrel, v -> StorageTracerConfig.barrel = v);
        addToggle(right, y, colWidth, "Furnace", () -> StorageTracerConfig.furnace, v -> StorageTracerConfig.furnace = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE"), b -> close())
                .dimensions(panelLeft + panelWidth - 82, panelTop + panelHeight - 27, 72, 20).build());
    }

    private void section(String name, int y) {
        // Section labels are painted in render() so the controls remain keyboard-focusable.
    }

    private void addToggle(int x, int y, int w, String name,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(label(name, getter.getAsBoolean()), b -> {
            boolean next = !getter.getAsBoolean();
            setter.accept(next);
            MarzzConfig.save();
            b.setMessage(label(name, next));
        }).dimensions(x, y, w, 20).build());
    }

    private static Text label(String name, boolean enabled) {
        return Text.literal((enabled ? "●  " : "○  ") + name + "  " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);

        // Layered panel, accent rail and inset surface give the menu depth without textures.
        context.fill(panelLeft - 3, panelTop - 3, panelLeft + panelWidth + 3, panelTop + panelHeight + 3, 0x99000000);
        context.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, PANEL);
        context.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, ACCENT);
        context.fill(panelLeft + 1, panelTop + 44, panelLeft + panelWidth - 1, panelTop + 45, 0xFF49375F);
        context.fill(panelLeft + 8, panelTop + 51, panelLeft + panelWidth - 8, panelTop + panelHeight - 34, PANEL_INNER);

        context.drawTextWithShadow(textRenderer, Text.literal("MARZZ"), panelLeft + 13, panelTop + 12, WHITE);
        context.drawTextWithShadow(textRenderer, Text.literal("CLIENT  /  CONTROL CENTER"), panelLeft + 76, panelTop + 14, ACCENT);
        context.drawTextWithShadow(textRenderer, Text.literal("RIGHT SHIFT  •  LOCAL SETTINGS"), panelLeft + 13, panelTop + 30, MUTED);

        int labelX = panelLeft + 15;
        context.drawTextWithShadow(textRenderer, Text.literal("HUD"), labelX, panelTop + 55, ACCENT);
        context.drawTextWithShadow(textRenderer, Text.literal("WORLD TOOLS"), labelX, panelTop + 133, ACCENT);
        context.drawTextWithShadow(textRenderer, Text.literal("STORAGE FILTERS"), labelX, panelTop + 211, ACCENT);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
